# MozMusic

Plataforma web para artistas e música moçambicana.

## Estrutura
- `index.html` — página inicial
- `style.css` — design
- `script.js` — interações e leitor
- `pages/` — páginas internas
- `assets/images/` — imagens, artistas e capas
- `assets/music/` — ficheiros de áudio

## Nota
O GitHub Pages publica a interface estática. Login real, base de dados, uploads persistentes, comentários e contas de utilizador precisam de um backend/serviço de dados numa fase posterior.
