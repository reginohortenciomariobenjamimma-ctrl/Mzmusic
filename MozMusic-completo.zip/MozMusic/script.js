const songs=[
 {title:"Minha História",artist:"Regino",cover:"🎵",src:"assets/music/minha-historia.mp3"},
 {title:"Saudade",artist:"Regino",cover:"🎧",src:"assets/music/saudade.mp3"},
 {title:"Poder do Metical",artist:"Anicleto Anelce & Regino",cover:"🎤",src:"assets/music/poder-do-metical.mp3"},
 {title:"Nova Geração",artist:"MozMusic Artist",cover:"🎶",src:"assets/music/nova-geracao.mp3"}
];
const artists=[
 {name:"Regino",genre:"Artista moçambicano",avatar:"👤"},
 {name:"Anicleto Anelce",genre:"Artista moçambicano",avatar:"🎤"},
 {name:"Novos Talentos",genre:"Moçambique",avatar:"⭐"},
 {name:"Artistas Mz",genre:"Moçambique",avatar:"🎧"}
];
function renderSongs(list=songs){
 const grid=document.getElementById("musicGrid");
 if(!grid)return;
 grid.innerHTML=list.map((s,i)=>`<article class="card"><div class="cover">${s.cover}</div><h3>${s.title}</h3><p class="muted">${s.artist}</p><button class="play" data-song="${i}">▶ Ouvir</button></article>`).join("");
 grid.querySelectorAll(".play").forEach(b=>b.addEventListener("click",()=>playSong(Number(b.dataset.song))));
}
function renderArtists(){
 const grid=document.getElementById("artistGrid");
 if(!grid)return;
 grid.innerHTML=artists.map(a=>`<article class="artist"><div class="avatar">${a.avatar}</div><h3>${a.name}</h3><p class="muted">${a.genre}</p></article>`).join("");
}
function playSong(i){
 const s=songs[i], player=document.getElementById("player"), audio=document.getElementById("audio");
 document.getElementById("playerCover").textContent=s.cover;
 document.getElementById("playerTitle").textContent=s.title;
 document.getElementById("playerArtist").textContent=s.artist;
 player.classList.remove("hidden");
 audio.src=s.src;
 audio.play().catch(()=>{});
}
document.getElementById("closePlayer")?.addEventListener("click",()=>document.getElementById("player").classList.add("hidden"));
document.getElementById("searchForm")?.addEventListener("submit",e=>{
 e.preventDefault();
 const q=document.getElementById("searchInput").value.trim().toLowerCase();
 renderSongs(q?songs.filter(s=>(s.title+" "+s.artist).toLowerCase().includes(q)):songs);
});
renderSongs();renderArtists();
